class GridBuilder:

    def build(store):
        ...